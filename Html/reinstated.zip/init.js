$(function() {
	$('#menu > ul').dropotron();
});